#include "Container.h"

// Constructor for Container class
Container::Container()
{
	employee = NULL;
	next = NULL;
}